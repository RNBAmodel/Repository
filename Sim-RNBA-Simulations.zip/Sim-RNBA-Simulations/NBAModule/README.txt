Python extension module with Python-C-API
Based on: 
http://www.scipy-lectures.org/advanced/interfacing_with_c/interfacing_with_c.html

Compiled with setup.py

run with terminal in directory: 

python setup.py build_ext --inplace


— build_ext is to build extension modules
--inplace will output the compiled extension module into the current directory

in python:

import <name>_module 

Here: 
import pop_module