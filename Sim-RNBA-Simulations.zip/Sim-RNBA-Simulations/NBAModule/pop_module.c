/*  
Wrapping population dynamics functions in C for RNBA simulations
with Python-C-API. Using math functions in C, with math.h. See README.txt
 */

#include <Python.h>
#include <math.h>

// External variables
#define tau_ex 0.4
#define tau_in 0.8
#define alfa 0.2
#define epsilon 0.20
#define gamma 0.20
#define delta 0.20
#define beta 2.
#define teta 5.
#define f_max 100.
#define w_all 0.20
// External variable for step size in 4th order Runge Kutta.
#define h 0.1

//Functions for derivatives
double deriv_ex(double E, double I, double Input){
    double r1 = alfa * E - epsilon * I + Input;
    double r2 = exp(-beta * (r1 - teta));
    double r3 = f_max / (1 + r2);
    return tau_ex * (-E + r3);
}

double deriv_in(double E, double I, double Input){
    double r1 = gamma * E - delta * I + Input;
    double r2 = exp(-beta * (r1 - teta));
    double r3 = f_max / (1 + r2);
    return tau_in * (-I + r3);
}

//Functions for derivatives with variable maximum activation f_max_v
double deriv_ex_f_max(double E, double I, double Input, double f_max_v){
    double r1 = alfa * E - epsilon * I + Input;
    double r2 = exp(-beta * (r1 - teta));
    double r3 = f_max_v / (1 + r2);
    return tau_ex * (-E + r3);
}

double deriv_in_f_max(double E, double I, double Input, double f_max_v){
    double r1 = gamma * E - delta * I + Input;
    double r2 = exp(-beta * (r1 - teta));
    double r3 = f_max_v / (1 + r2);
    return tau_in * (-I + r3);
}

/*  Wrapped population dynamics function */
static PyObject* pop_func(PyObject* self, PyObject* args)
{
    double excit;
    double inhib;
    double exc_input;
    double inh_input;
    
    /*  parse the input, from python float to c double */
    if (!PyArg_ParseTuple(args, "dddd", &excit, &inhib, &exc_input, &inh_input))
        return NULL;
    /* if the above function returns -1, an appropriate Python exception will
     * have been set, and the function simply returns NULL
     */
    
    double K1 = h * deriv_ex(excit, inhib, exc_input);
    double L1 = h * deriv_in(excit, inhib, inh_input);
    double K2 = h * deriv_ex(excit + 0.5 * K1, inhib + 0.5 * L1, exc_input);
    double L2 = h * deriv_in(excit + 0.5 * K1, inhib + 0.5 * L1, inh_input);
    double K3 = h * deriv_ex(excit + 0.5 * K2, inhib + 0.5 * L2, exc_input);
    double L3 = h * deriv_in(excit + 0.5 * K2, inhib + 0.5 * L2, inh_input);
    double K4 = h * deriv_ex(excit + K3, inhib + L3, exc_input);
    double L4 = h * deriv_in(excit + K3, inhib + L3, inh_input);
    double nexcit = excit + (1 / 6.0) * (K1 + 2 * K2 + 2 * K3 + K4);
    double ninhib = inhib + (1 / 6.0) * (L1 + 2 * L2 + 2 * L3 + L4);
    
    /*  construct the output from pop, from c double to python float */
    return Py_BuildValue("ff", nexcit, ninhib);
}

/*  Wrapped population dynamics function with variable maximum activation f_max_v*/
static PyObject* delay_func(PyObject* self, PyObject* args)
{
    double excit;
    double inhib;
    double exc_input;
    double inh_input;
    double f_max_v;
    
    /*  parse the input, from python float to c double */
    if (!PyArg_ParseTuple(args, "ddddd", &excit, &inhib, &exc_input, &inh_input, &f_max_v))
        return NULL;
    /* if the above function returns -1, an appropriate Python exception will
     * have been set, and the function simply returns NULL
     */
    
    double K1 = h*deriv_ex_f_max(excit, inhib, exc_input, f_max_v);
    double L1 = h*deriv_in_f_max(excit, inhib, inh_input, f_max_v);
    double K2 = h*deriv_ex_f_max(excit + 0.5 * K1, inhib + 0.5 * L1, exc_input, f_max_v);
    double L2 = h*deriv_in_f_max(excit + 0.5 * K1, inhib + 0.5 * L1, inh_input, f_max_v);
    double K3 = h*deriv_ex_f_max(excit + 0.5 * K2, inhib + 0.5 * L2, exc_input, f_max_v);
    double L3 = h*deriv_in_f_max(excit + 0.5 * K2, inhib + 0.5 * L2, inh_input, f_max_v);
    double K4 = h*deriv_ex_f_max(excit + K3, inhib + L3, exc_input, f_max_v);
    double L4 = h*deriv_in_f_max(excit + K3, inhib + L3, inh_input, f_max_v);
    double nexcit = excit + (1 / 6.0) * (K1 + 2 * K2 + 2 * K3 + K4);
    double ninhib = inhib + (1 / 6.0) * (L1 + 2 * L2 + 2 * L3 + L4);
    
    /*  construct the output from delay, from c double to python float */
    return Py_BuildValue("ff", nexcit, ninhib);
}


/*  define functions in module  */
static PyMethodDef PopMethods[] =
{
    {"pop_func", pop_func, METH_VARARGS, "evaluate the pop dynamics"},
    {"delay_func", delay_func, METH_VARARGS, "evaluate the pop delay dynamics"},
    {NULL, NULL, 0, NULL}
};


static struct PyModuleDef pop_module =
{
    PyModuleDef_HEAD_INIT,
    "pop_module", /* name of module */
    "",          /* module documentation, may be NULL */
    -1,          /* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
    PopMethods
};

PyMODINIT_FUNC PyInit_pop_module(void)
{
    return PyModule_Create(&pop_module);
}









