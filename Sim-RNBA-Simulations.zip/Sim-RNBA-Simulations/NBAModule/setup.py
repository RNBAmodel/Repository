
from distutils.core import setup, Extension

# define the extension module
pop_module = Extension('pop_module', sources=['pop_module.c'])

# run the setup
setup(ext_modules=[pop_module])

