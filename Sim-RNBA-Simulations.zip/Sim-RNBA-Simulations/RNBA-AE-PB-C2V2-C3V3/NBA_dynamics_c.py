"""
With C extension module "pop_module" to import pop_module.c
Basis of population dynamics implemented in C
In particular: function "pop_step_wc_m" in Python RNBA simulation program

Import module for RNBA simulations

Dynamics based on Wilson Cowan populations
Wilson Cowan: two combined populations: E (excitatory) and I (inhibitory). 
Population dynamics calculated with 4th order Runge Kutta numerical 
integration. Populations can receive external input. 
Input assumed to be constant during each step in Runge Kutta.
"""

import numpy as np
import pop_module

"""
Functions for calculating the derivatives in pop_module.c
E, I = excitatory, inbibitory populations. E,I are arrays.
Input = external input to E, I populations.
alfa, epsilon = constants for time derivative of E.
gamma, delta = constants for time derivative of I.
f_max = maximum activation for logistic function. 
tau_ex, tau_in = time constants for E, I.
beta, teta = constants in logistic function (teta = threshold).
"""

"""
Function for calculating one step in 4th order Runge Kutta. 
ips = index step in for loop of simulation run.
excit, inhib = array exc (inh) values of E, I.
exc_input, inh_input = array external input (assumed constant in each step).
h = step size, h is external variable.
Here: input not with array
pop_step_wc_m:  WC calculation in matrix form
"""
def pop_step_wc_m(i, k, excit, inhib, exc_input, inh_input):
    new_excit, new_inhib = pop_module.pop_func(excit[i,k], inhib[i,k], exc_input, inh_input)
    excit[i + 1, k] = new_excit
    inhib[i + 1, k] = new_inhib
    return excit[i + 1, k], inhib[i + 1, k]


"""
Parameters:
External variable for step size in 4th order Runge Kutta: h = 0.1
time constants tau_ex, tau_in for E, I. Already in the form of 1/tau. 
constants for derivatives of E, I, and logistic function: 
alfa, epsilon for E
gamma, delta for I
beta, teta for logistic function
f_max = maximum activation population
w_all = (basis) all connection weights
"""













