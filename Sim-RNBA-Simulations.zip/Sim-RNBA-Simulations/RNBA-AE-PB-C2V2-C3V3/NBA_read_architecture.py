"""
Program to read RNBA architecture.txt file
Output:
Number of populations (lenlist)
Architecture file used in simulation
Input connections for each population in architecture file used in simulation
"""
  
# NBA modules:
import numpy as np

def NBA_read_architecture(file_architecture):

    # Lists used for read of architecture:
    connection_types_read = []
    populationType_read = []
    population_id_read = []
    circuit_read = []
    columnH_read = []
    columnD_read = []
    matrix_read = [] 
    list_inputConnections = []
    counter = 0

    # Reading architecture from file. 
    with open(file_architecture) as f:
        f.readline()
        line = f.readline()
        str = line.split()
        lenlist_read =  int(str[1])
        f.readline()
        f.readline()
        f.readline()
        for line in f:
            str = line.split()
            # reading architecture identities. str[0] = pop index
            connection_types_read.append(str[1])
            populationType_read.append(str[2])
            population_id_read.append(str[3]) 
            circuit_read.append(str[4])
            columnH_read.append(str[5])
            columnD_read.append(str[6])
            matrix_read.append(str[7])
            # reading connection_input
            list_inputConnections.append([])
            connect_len = len(str) - 8
            if connect_len > 0:
                for q in range(connect_len):
                    list_inputConnections[counter].append(q)
                    list_inputConnections[counter][q] = int(str[q + 8])
            counter += 1


    # Determining and testing length of lists. 
    if len(connection_types_read) != lenlist_read:
        print('List length does not match for connection_types_read ',  len(connection_types_read) ) 
    if len(populationType_read) != lenlist_read:
        print('List length does not match for  populationType_read ',  len( populationType_read) ) 
    if len(population_id_read) != lenlist_read:
        print(' List length does not match for population_id_read ',  len(population_id_read) ) 
    if len(circuit_read) != lenlist_read:
        print(' List length does not match for circuit_read ',  len(circuit_read) ) 
    if len(columnH_read) != lenlist_read:
        print(' List length does not match for columnH_read ',  len(columnH_read) ) 
    if len(columnD_read) != lenlist_read:
        print(' List length does not match for columnD_read ',  len(columnD_read) ) 
    if len(matrix_read) != lenlist_read:
        print(' List length does not match for matrix_read ',  len(matrix_read) ) 
     
    # Collection architecture features in one list
    architecture = []
    for i in range(lenlist_read):
        architecture.append([])
        for k in range(7):
            architecture[i].append(k)
       
    for i in range(lenlist_read):
        architecture[i][0] = connection_types_read[i]
        architecture[i][1] = populationType_read[i]
        architecture[i][2] = population_id_read[i]
        architecture[i][3] = circuit_read[i]
        architecture[i][4] = columnH_read[i]
        architecture[i][5] = columnD_read[i]
        architecture[i][6] = matrix_read[i] 

    # Test length of input connections list
    if len(list_inputConnections) != lenlist_read:
        print(' List length does not match for list_inputConnections',  len(list_inputConnections) )

    lenlist = lenlist_read

    return lenlist, architecture, list_inputConnections

