"""
Program to read and translate question instruction file
for question input in simulation RNBA, SGall version.
Main difference with sentence instructions: no fixed_time. 
End time has to be given explicitly.
Word MA = Word population
"""

import numpy as np
import NBA_read_architecture as nr

# List to collect start and end times and population index numbers
list_Input = []

# Lists of population and circuit identities

# Related to LMAs: LMA W binding in architecture and instruction terms used in function Sentence_file 
list_LMA_names = []
list_LMA = []      # HERE: list of LMA full names for actvation and binding instructions in sentence.txt file   (A3)
# LMA related  instruction terms used in function Sentence_file 
list_LMA_head = []                # list of LMA head instructions
list_LMA_dependent = []       # list of LMA dependent instructions
list_LMA_inhib_instruction = []      # list of LMA inhibition instructions
list_LMA_inhib_input = []      # List of external populations to inhibit LMAs of same type     EX0
list_LMA_CMtoW_H = []    # List of intruction terms for LMA out gates (B2a) for CMtoW in H rows  (see EX8H)
list_LMA_CMtoW_D = []    # List of intruction terms for LMA out gates (B2a) for CMtoW in D rows  (see EX8D)
#  LMA related External populations. 
list_EX_control_BgateWtoLMA = []  # External control of Binding gates from W to lexical MAs.   EX2
list_EX_control_gateLMAtoSG_H = []  #  External control of gates from lexical MAs to SG-H Groups   EX3H
list_EX_control_gateLMAtoSG_D = []  #  External control of gates from lexical MAs to SG-D Groups   EX3D
list_EX_LMA_out_H = []      # List of external activation of gating circuit (B2a) for LMA selection of output in H rows EX8H 
list_EX_LMA_out_D = []      # List of external activation of gating circuit (B2a) for LMA selection of output in D rows EX8D 

# Related to SGs in architecture and instruction terms used in function Sentence_file 
list_SG_names  = []
list_SG_binding_H = []  # list of SG Head binding instructions     for  EX4H on  B1
list_SG_binding_D = []  # list of SG Dependent binding instructions      for  EX4D on  B1
list_SG_H = []  # list of SG Head control instructions           for  EX6H  on  B8
list_SG_D = []  # list of SG Dependent control instructions     for  EX6D on  B8
list_SG_W_H= []   # List control gates Head SG to W MA  instructions       for  EX5H on  B12 
list_SG_W_D= []   # List control gates Dependent SG to W MA  instructions       for  EX5D on  B12
list_SG_comp_inh_H = []     # List of instructions for pops to inhib SG_comp pops in H rows  for EX7H  on   B3a
list_SG_comp_inh_D = []     # List of instructions for pops to inhib SG_comp pops in D rows  for EX7D  on   B3a
# SG related External populations
list_EX_control_Bgate_SG_H = []  # List of external control Binding gates H rows between LMAs and SG SAs    EX4H
list_EX_control_Bgate_SG_D = []  # List of external control Binding gates D rows between LMAs and SG SAs    EX4D
list_EX_control_gate_SG_W_H = []   # List of external control gates SG to W MA in H rows      EX5H    
list_EX_control_gate_SG_W_D = []   # List of external control gates SG to W MA in D rows      EX5D    
list_EX_control_gate_SA_CM_H = []    # List external control of gates SA to CM in H rows      EX6H
list_EX_control_gate_SA_CM_D = []    # List external control of gates SA to CM in D rows      EX6D
list_EX_SG_comp_inhib_H = []   # List of external activation of local SG_comp_inhib pops in H rows  EX7H
list_EX_SG_comp_inhib_D = []   # List of external activation of local SG_comp_inhib pops in D rows  EX7D


# Word input
Word = 'Word'
# Word inhibition
Word_inhibition = 'Word_inhib'         #   EX0a
# Word inhibition pop identity
Word_inhibition_id = 'EX0a_inhib_W_all'

# Making lists of external populations in NBA architecture
# Based on function nbaBuild_Circuit
# List of short Lexical Main Assemby names
list_LMA_names.append('Adj')          # 1
list_LMA_names.append('Adv')         # 2
list_LMA_names.append('C')             # 3
list_LMA_names.append('Co')           # 4
list_LMA_names.append('Det')          # 5
list_LMA_names.append('N')             # 6
list_LMA_names.append('P')             # 7
list_LMA_names.append('Pr')            # 8
list_LMA_names.append('V')             # 9

# List of Structure Groups/Gates (SGs) names
list_SG_names.append('SG1Verb')
list_SG_names.append('SG2Subject')
list_SG_names.append('SG3Object')
list_SG_names.append('SG4Det')
list_SG_names.append('SG5Compl')
list_SG_names.append('SG6Mod')
list_SG_names.append('SG7Adjunct')
list_SG_names.append('SG8PC')  
list_SG_names.append('SG9Ex_Mod')
list_SG_names.append('SG10Coord')
list_SG_names.append('SG11GAP')

num_LMA = len(list_LMA_names)
num_SG = len(list_SG_names)

# Externally controlled MAs and gates in Word group
for i in range(num_LMA):
    add_LMA = list_LMA_names[i]
    # Fill list of external populations to inhibit LMAs of same type     EX0  
    list_LMA_inhib_input.append('EX0_inhib_'+add_LMA)   
    # Fill  External control of Binding gates from W to lexical MAs.        EX2
    list_EX_control_BgateWtoLMA.append('EX2_Bgate_W_'+add_LMA) 
    # Fill list External control of gates from lexical MAs to SG-H Groups      EX3H
    list_EX_control_gateLMAtoSG_H.append('EX3H_Gate_'+add_LMA+'_H')
    # Fill list External control of gates from lexical MAs to SG-H Groups      EX3D
    list_EX_control_gateLMAtoSG_D.append('EX3D_Gate_'+add_LMA+'_D')
    # Fill in list external disinhibtion LMA_out gating circuits in H rows             EX8H   
    list_EX_LMA_out_H.append('EX8H_LMA_out_'+add_LMA+'_H')                                
    # Fill in list external disinhibtion LMA_out gating circuits in D rows             EX8D   
    list_EX_LMA_out_D.append('EX8D_LMA_out_'+add_LMA+'_D')                                


# Structure Groups/Gates: externally controlled gates
for i in range(num_SG):
     add_SG = list_SG_names[i]
     # Fill in list of external control of Binding gates H rows between LMAs and SG SAs       EX4H
     list_EX_control_Bgate_SG_H.append('EX4H_Bgate_LMA_'+add_SG+'_H')
     # Fill in list of external control Binding gates D rows between LMAs and SG SAs    EX4D
     list_EX_control_Bgate_SG_D.append('EX4D_Bgate_LMA_'+add_SG+'_D')
     # Fill in list external control of gates SA to CM in H rows                                       EX6H
     list_EX_control_gate_SA_CM_H.append('EX6H_Gate_'+add_SG+'_CM_H')
     # Fill in list external control of gates SA to CM in D rows                                       EX6D
     list_EX_control_gate_SA_CM_D.append('EX6D_Gate_'+add_SG+'_CM_D')
     # Fill in list external control of gates SG to W MA in H rows                               EX5H    
     list_EX_control_gate_SG_W_H.append('EX5H_Gate_'+add_SG+'_W_H')
     # Fill in list external control of gates SG to W MA in D rows                               EX5D   
     list_EX_control_gate_SG_W_D.append('EX5D_Gate_'+add_SG+'_W_D')
     # Fill in list external activation SG_comp inhibition pops in H rows                                EX7H
     list_EX_SG_comp_inhib_H.append('EX7H_SG_comp_inhib_'+add_SG+'_H')
     # Fill in list external activation SG_comp inhibition pops in D rows                                EX7D
     list_EX_SG_comp_inhib_D.append('EX7D_SG_comp_inhib_'+add_SG+'_D')
        
# Making list with LMA and SG sentence instructions
# Used to determine external input related to sentence structure. 
# List of full Lexical Main Assemby names. Also used as list of LMA binding instructions  
list_LMA.append('Adjective')             # 1
list_LMA.append('Adverb')                 # 2
list_LMA.append('Clause')                  # 3
list_LMA.append('Coordinator')           # 4
list_LMA.append('Determiner')          # 5
list_LMA.append('Noun')                   # 6
list_LMA.append('Preposition')          # 7
list_LMA.append('Pronoun')              # 8
list_LMA.append('Verb')                    # 9
list_LMA.append('Sentence')             # 10

# Filling in instruction lists
# For LMAs
for i in range(num_LMA):
    add_LMA = list_LMA[i]
    # Fill in list for LMA head instructions
    list_LMA_head.append(add_LMA+'_H')
    # Fill in list for LMA dependent instructions  
    list_LMA_dependent.append(add_LMA+'_D')
    # Fill in list for LMA inhibition instructions
    list_LMA_inhib_instruction.append(add_LMA+'_inhib')
    # Fill list of intruction terms for LMA out gates (B2a) for CMtoW in H rows  (see EX8H)
    list_LMA_CMtoW_H.append('CMtoW_'+ add_LMA+'_H')
    # Fill list of intruction terms for LMA out gates (B2a) for CMtoW in D rows  (see EX8D)
    list_LMA_CMtoW_D.append('CMtoW_'+ add_LMA+'_D')

# For SGs
for i in range(num_SG):
     add_SG = list_SG_names[i]
     # Fill in list of SG Head binding instructions   
     list_SG_binding_H.append('binding_'+add_SG+'_H')
     # Fill in list of SG Dependent binding instructions    
     list_SG_binding_D.append('binding_'+add_SG+'_D')
     # list of SG Head control instructions
     list_SG_H.append(add_SG+'_H')
     # list of SG Dependent control instructions    
     list_SG_D.append(add_SG+'_D')
     # List control gates Head SG to W MA instructions (for QA)
     list_SG_W_H.append(add_SG+'_W_H')
     # List control gates Depedent SG to W MA instructions (for QA)
     list_SG_W_D.append(add_SG+'_W_D')
     # List of instructions for pops to inhib SG_comp pops in H rows  for EX7H  on   B3a
     list_SG_comp_inh_H.append('inhibcomp_'+add_SG+'_H')
     # List of instructions for pops to inhib SG_comp pops in D rows  for EX7D  on   B3a
     list_SG_comp_inh_D.append('inhibcomp_'+add_SG+'_D')

# Definitions of functions used in main function Sentence_file 
# Function for finding popuation numbers in architecture
def populationFinder(population_type, architecture):
    population_number = -1
    for i in range(len(architecture)):
        if architecture[i][2] == population_type:
            population_number = i
    return population_number

# Function for filling in inputList
def inputPopulation(start_time, stop_time, population_type, architecture, inputList=list_Input):
    number_population = populationFinder(population_type, architecture)    
    inputList.append([])
    size = len(inputList)
    inputList[size - 1].append(start_time)
    inputList[size - 1].append(stop_time)
    inputList[size - 1].append(number_population)
    return inputList


#   Main function Sentence_file: 
#   Generating a list of populations that are activated as input
#   based on given question instructions

def Sentence_file(inputFile, architecture):
    # First part:
    with open(inputFile) as f:
        step_size = 0
        start_time = 0
        end_time = 0
        for line in f:
            str = line.split()
            if len(str) > 0 and line[0] !='#':
                if str[0] == 'Num_of_words':
                    number_of_words =  int(str[1])
                    word_list = []   
                    for k in range(number_of_words):
                        word_list.append(('EX1_input_W%d' %k))           #  EX1
                # Word input
                if str[0] == Word:
                    start_time =  step_size + eval((str[1]))
                    step_size = start_time
                    end_time =  step_size + eval((str[2]))
                    inputPopulation(start_time, end_time,  word_list[ int(str[3])], architecture )
                # Word inhibition
                if str[0] == Word_inhibition: 
                    pop_id = Word_inhibition_id   
                    start_time =  step_size + eval((str[1]))
                    end_time =  step_size + eval((str[2]))
                    inputPopulation(start_time, end_time, pop_id, architecture)                
                # LMA input
                for i in range(num_LMA):
                    # Instruction for binding LMA to W        EX2
                    if str[0] ==list_LMA[i]:
                        pop_id = list_EX_control_BgateWtoLMA[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for control LMA Head        EX3H
                    if str[0] == list_LMA_head[i]:
                        pop_id = list_EX_control_gateLMAtoSG_H[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for control LMA Dependent       EX3D
                    if str[0] == list_LMA_dependent[i]:
                        pop_id = list_EX_control_gateLMAtoSG_D[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for control LMA out (from CM to Word MA) in H row   EX8H
                    if str[0] == list_LMA_CMtoW_H[i]:
                        pop_id = list_EX_LMA_out_H[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for control LMA out (from CM to Word MA) in D row   EX8D
                    if str[0] == list_LMA_CMtoW_D[i]:
                        pop_id = list_EX_LMA_out_D[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for inhibition LMA                  EX0
                    if str[0] == list_LMA_inhib_instruction[i]:
                        pop_id = list_LMA_inhib_input[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                # SG input
                for i in range(num_SG):
                    # Instruction for SG binding Head           EX4H
                    if str[0] == list_SG_binding_H[i]:
                        pop_id = list_EX_control_Bgate_SG_H[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for SG binding Dependent         EX4D
                    if str[0] == list_SG_binding_D[i]:
                        pop_id = list_EX_control_Bgate_SG_D[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for SG control Head                EX6H
                    if str[0] == list_SG_H[i]:
                        pop_id = list_EX_control_gate_SA_CM_H[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for SG control Dependent         EX6D
                    if str[0] == list_SG_D[i]:
                        pop_id =list_EX_control_gate_SA_CM_D[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for control SG to W Head                EX5H
                    if str[0] == list_SG_W_H[i]:
                        pop_id = list_EX_control_gate_SG_W_H[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for control SG to W Dependent         EX5D
                    if str[0] == list_SG_W_D[i]:
                        pop_id = list_EX_control_gate_SG_W_D[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for inhibition SG_comp pop In Head row  EX7H
                    if str[0] == list_SG_comp_inh_H[i]:
                        pop_id = list_EX_SG_comp_inhib_H[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)
                    # Instruction for inhibition SG_comp pop In Head row  EX7D
                    if str[0] == list_SG_comp_inh_D[i]:
                        pop_id = list_EX_SG_comp_inhib_D[i]
                        start_time =  step_size + eval((str[1]))
                        end_time =  step_size + eval((str[2]))
                        inputPopulation(start_time, end_time, pop_id, architecture)

                    
   
    return list_Input  


