"""
RNBA simulation program 

Topics:
Population, Working memory (WM) population,
Gating circuit and Binding circuit
Uses RNBA_Circuits.txt as architecture
"""

# NBA modules:
import numpy as np
import matplotlib.pyplot as plt
import NBA_dynamics_c as nc
import NBA_read_architecture as nr

# Population type
normal = 'normal'                 # population in architecture     

# general weight (normal_excitation)
w_all = 0.2

# Connection type labels:
normal_excitation =  'excitation'    
normal_inhibition = 'inhibition'
weak_inhibition = 'weak_inhib'
strong_inhibition = 'strong_inh'
weak_excitation =  'weak_excit'

# Connection type values:
normal_excitation_value = w_all
normal_inhibition_value = w_all
weak_inhibition_value = 0.7*w_all
strong_inhibition_value = 1.5*w_all
weak_excitation_value = 0.25*w_all               

# architecture
file_architecture = 'RNBA_Circuits.txt'
print('Architecture used: ', file_architecture)

# read in architecture
lenlist, architecture, list_inputConnections = nr.NBA_read_architecture(file_architecture)

# number of time steps
n = 2500

#Basis for population matrices
x = np.zeros(n*lenlist)         
y = x.reshape(n,lenlist)

# four types of populations in this version of NBA
excitPop = y.copy()                   # exitation populations for Wilson Cowan, normal populations
inhibPop = y.copy()                   # inhibition populations for Wilson Cowan, normal populations

for i in range(n-1):                 # loop over time steps
    for q in range(lenlist):       # loop over population index
        if i > 0:
            excitPop[i, 0] = 100   # input to start population 2 (Gating circuit) and  8 (Binding circuit)
        if i > 0:
            excitPop[i, 12] = 100   # input to population 13 for WC and WM populations
        if i > 400:
            excitPop[i, 12] = 0   # stop input to population 13 for WC and WM populations
        if i > 500:    
            excitPop[i, 1] = 100   # input to disinhibition population 5 (Gating circuit) and 11 (Binding circuit)
        if i > 1000:    
            excitPop[i, 1] = 0   # stop input to disinhibition population 5 (Gating circuit) and 11 (Binding circuit)    
        if i > 1500:
            excitPop[i, 0] = 0   #  stop input to start population 2 (Gating circuit) and  8 (Binding circuit)
        if i > 2000:
            excitPop[i, 0] = 100   # input to start population 2 (Gating circuit) and  8 (Binding circuit)

    # Calculating dynamics at each time step (i), for each normal population (q) in architecture
    # First: calculate inputSum based on (list of) input connections and connection type 
        inputSum = 0.0
        numberConnections = len(list_inputConnections[q])
        if numberConnections > 0:
            for k in range(numberConnections):        # determine input populations, listed in list_inputConnections
                inputpopindex = list_inputConnections[q][k]        # retrieved input population
                if architecture[inputpopindex][0] == normal_excitation:            # normal excitation
                    inputSum += normal_excitation_value*excitPop[i, inputpopindex]
                if architecture[inputpopindex][0] ==  weak_excitation:            # weak excitation
                    inputSum += weak_excitation_value*excitPop[i, inputpopindex]
                if architecture[inputpopindex][0] == normal_inhibition:               # normal inhibition
                    inputSum -= normal_inhibition_value*inhibPop[i, inputpopindex]
                if architecture[inputpopindex][0] == weak_inhibition:            # weak inhibition
                    inputSum -= weak_inhibition_value*inhibPop[i, inputpopindex]
                if architecture[inputpopindex][0] == strong_inhibition:           # strong inhibition
                    inputSum -= strong_inhibition_value*inhibPop[i, inputpopindex]

        # Second: calculate dynamics for normal population
        if architecture[q][1] == normal:                 # normal population            
           nc.pop_step_wc_m(i, q, excitPop, inhibPop, inputSum, inputSum)

# Plotting
drop = 0.05   # reduce plotted activity

print('Select the circuit:')
print('Population = 0:')
print('Working memory population = 1')
print('Gating circuit = 2')
print('Binding circuit = 3')

circuit_select_in = input('Select 0, 1, 2 or 3:   ')
circuit_select = int(circuit_select_in )

if circuit_select == 0:
    # Wilson Cowan population
    x_axis = np.linspace(0, 600, 600)
    plt.figure(dpi=300)
    plt.plot(x_axis, excitPop[:600, 13], color='red')   #  population GC_gate excitatory
    plt.plot(x_axis, inhibPop[:600, 13], color='blue')   #  population GC_gate inhibitory
    plt.ylim(0, 170)
    plt.xlabel('Time (ms)')
    plt.ylabel('Activity')
    plt.title('Population')
    plt.savefig('Population.png')
    plt.close('Population.png')
    print('Excitatory population = red')
    print('Inhibitory population = blue')
    print('Input (= 100) between 0 and 400')

if circuit_select == 1:
    # Working memory population
    x_axis = np.linspace(0, 1500, 1500)
    plt.figure(dpi=300)
    plt.plot(x_axis, excitPop[:1500, 14], color='red')   #  population WM_A 
    plt.ylim(0, 170)
    plt.xlabel('Time (ms)')
    plt.ylabel('Activity')
    plt.title('Working memory population')
    plt.savefig('Working memory population.png')
    plt.close('Working memory population.png')
    print('Excitatory population WM_A = red')
    print('Input (= 100) between 0 and 400')

if circuit_select == 2:
    # Gating circuit
    x_axis = np.linspace(0, n, n)
    plt.figure(dpi=300)
    plt.plot(x_axis, excitPop[:, 8], color='purple')   #  start
    scale_factor = 1 - drop
    plt.plot(x_axis, scale_factor*excitPop[:, 9], color='red')   # gate
    scale_factor = 1 - 2*drop
    plt.plot(x_axis, scale_factor*excitPop[:, 10], '--', color='magenta')  # inhibition
    scale_factor = 1 - 3*drop
    plt.plot(x_axis, scale_factor*excitPop[:, 11], color='blue')   # dis inhibition
    plt.ylim(0, 170)
    plt.xlabel('Time (ms)')
    plt.ylabel('Activity')
    plt.title('Gating circuit')
    plt.savefig('Gating circuit.png')
    plt.close('Gating circuit.png')
    print('Population start = purple (solid, at 100%)')
    print('Population gate = red (solid, at 95%)')
    print('Population inhib = magenta (dash, at 90%)')
    print('Population dis-inhib = blue (solid, at 85%)')
    print('Input (100) start between 0 and 1500 and between 2000 and 2500 (end)')
    print('Input (100) dis-inhib between 500 and 1000')

if circuit_select == 3:
    # Binding circuit
    x_axis = np.linspace(0, n, n)
    plt.figure(dpi=300)
    plt.plot(x_axis, excitPop[:, 2], color='purple')   #  start
    scale_factor = 1 - drop
    plt.plot(x_axis, scale_factor*excitPop[:, 3], color='red')   # gate
    scale_factor = 1 - 2*drop
    plt.plot(x_axis, scale_factor*excitPop[:, 4], '--', color='magenta')  # inhibition
    scale_factor = 1 - 3*drop
    plt.plot(x_axis, scale_factor*excitPop[:, 5], color='blue')   # dis inhibition
    scale_factor = 1 - 4*drop
    plt.plot(x_axis, scale_factor*excitPop[:, 6], '--', color= 'black')  #  WM A
    plt.ylim(0, 170)
    plt.xlabel('Time (ms)')
    plt.ylabel('Activity')
    plt.title('Binding circuit')
    plt.savefig('Binding circuit.png')
    plt.close('Binding circuit.png')
    print('Population start = purple (solid, at 100%)')
    print('Population gate = red (solid, at 95%)')
    print('Population inhib = magenta (dash, at 90%)')
    print('Population dis-inhib = blue (solid, at 85%)')
    print('Excitatory population WM_A = black (dash, at 80%)')
    print('Input (100) start between 0 and 1500 and between 2000 and 2500 (end)')
    print('Input (100) dis-inhib between 500 and 1000')
    

    



