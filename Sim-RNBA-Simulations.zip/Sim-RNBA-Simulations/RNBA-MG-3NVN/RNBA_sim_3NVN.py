"""
RNBA simulation program 
Topic: 3NVN simulation, for Question Answering (QA)
Sentences: 3 Noun Verb Noun (NVN) 
Simulation based on population (pop) dynamics
"""

# MODULES
# Modules, standard:
import numpy as np 
import matplotlib.pyplot as plt
# NBA modules, specific:
import NBA_dynamics_c as nc    # Program for computations in C.  Via 'pop_module so' file
import NBA_read_architecture as nr    # Program to read architecture file. 

print('RNBA simulation of 3 Noun Verb Noun (NVN) sentences for Question Answering (QA)')

# INPUT SELECTIONS
# Selection type architecture
import NBA_SGall_sentence_input as ns   # Program to read sentence input file
NBA_arch = 'RNBA_arch_SGall'
Binding_test = 'RNBA_SGall'

# Selection size architecture
arch_size = '_SNB15'     

# Selection of sentence:
input_name = '3NVN'
      
# Name of architecture input file
file_architecture = NBA_arch+arch_size+'.txt'

# Name for sentence input file
sentence_prefix = 'Sentence_'
NBA_name = 'RNBA_SGall'

# Basis names output files
sentence_name = sentence_prefix+input_name
name_sim = '_'+sentence_name+arch_size

# Simulation time 3NVN sentences:
n = 5000    

# Read in architecture input file
lenlist, architecture, list_inputConnections = nr.NBA_read_architecture(file_architecture)
 
# Read in sentence input file:
inputFile = sentence_name+'.txt'
list_Input = ns.Sentence_file(inputFile, architecture)     

# Terminal output for checking
print('Number of time steps in simulation:  ', n)
print('Architecture used in simulation:  ', file_architecture)
print('Total number of populations:  ', lenlist)
print('Sentence name:  ', sentence_name)
print('Sentence instructions [start time, end time, population index number]:')
print(list_Input)

# SIMULATION
# Population type (pop_typ)
normal = 'normal'            # normal population: all SNB pops (not: external)      

# general weight (normal_excitation)
w_all = 0.2

# Connection type labels:
normal_excitation =  'excitation'    
normal_inhibition = 'inhibition'
weak_inhibition = 'weak_inhib'
strong_inhibition = 'strong_inh'
weak_excitation =  'weak_excit'

# Connection type values:
normal_excitation_value = w_all
normal_inhibition_value = w_all
weak_inhibition_value = 0.7*w_all
strong_inhibition_value = 1.5*w_all
weak_excitation_value = 0.05               

# Simulation files
x = np.zeros(n*lenlist) 
y = x.reshape(n,lenlist)

# Sub-populations
excitPop = y.copy()                   # exitation sub-populations, normal populations
inhibPop = y.copy()                   # inhibition sub-populations, normal populations

# Simulation of architecture
for i in range(n-1):                                    # loop over time steps
    for q in range(lenlist):                          # loop over population index
        # External input
        for k in range(len(list_Input)):          # loop over list of external (sentence) inputs
            if i > list_Input[k][0] and i < list_Input[k][1]  + 1:   
                excitPop[i, list_Input[k][2]] = 100
                inhibPop[i, list_Input[k][2]] = 100
       
        # Calculating dynamics at each time step (i), for each normal population (q) in architecture
        # First: calculate inputSum based on (list of) input connections and connection type 
        inputSum = 0.0
        numberConnections = len(list_inputConnections[q])
        if numberConnections > 0:
            for k in range(numberConnections):        # determine input populations, listed in list_inputConnections
                inputpopindex = list_inputConnections[q][k]        # retrieved input population
                if architecture[inputpopindex][0] == normal_excitation:             # normal excitation
                    inputSum += normal_excitation_value*excitPop[i, inputpopindex]
                if architecture[inputpopindex][0] ==  weak_excitation:               # weak excitation
                    inputSum += weak_excitation_value*excitPop[i, inputpopindex]
                if architecture[inputpopindex][0] == normal_inhibition:              # normal inhibition
                    inputSum -= normal_inhibition_value*inhibPop[i, inputpopindex]
                if architecture[inputpopindex][0] == weak_inhibition:                 # weak inhibition
                    inputSum -= weak_inhibition_value*inhibPop[i, inputpopindex]
                if architecture[inputpopindex][0] == strong_inhibition:               # strong inhibition
                    inputSum -= strong_inhibition_value*inhibPop[i, inputpopindex]

        # Second: calculate dynamics for normal population
        if architecture[q][1] == normal:                 # normal population            
           nc.pop_step_wc_m(i, q, excitPop, inhibPop, inputSum, inputSum)
             
# End: dynamics architecture
print('End simulations, summarizing output')

# OUTPUT
# Summarizing activity 

# Files to collect activity per category
GC_sum_act = np.zeros(n)  # For summarizing GC activity
MA_sum_act = np.zeros(n)  # For summarizing MA activity 
SG_sum_act = np.zeros(n)  # For summarizing SG activity 
WM_sum_act = np.zeros(n)  # For summarizing activity WM activity for WM pops
HD_sum_act = np.zeros(n)  # For summarizing activity H and D activity 
EX_sum_act = np.zeros(n)  # For summarizing External activity 
#NB: LMA, SA and SA_WM activity is summed as WM pops (they are WM circuits)
Sum_act_Total = np.zeros(n)  #For summarizing all activity in SNB
Sum_act_Rest = np.zeros(n)   # For all Other sum act in SNB without GC and WM activity (Thus: SG + MA + HD)

# Counting number of pops per category
EX_counter = 0           # number of External pops
GC_counter = 0          # number of pops in Gating and binding Circuits
MA_counter = 0          # number of Word pops and pops to inhibit LMAs
WM_counter = 0     # number of Working Memory pops
SG_counter = 0           # number of pops in SGs, except SAs and SA_WMs
HD_counter = 0          # number of pops for input from and output to CM
# NB: LMAs, SAs and SA_WMs are implemented as circuits of WM pops
NBA_counter = 0       # all pops in SNB
Pops_counter = 0      # total pops: SNB + External

# Summarize activity and number of pops per category (see above)
for q in range(lenlist):
    population_identity = architecture[q][2]
    # Count and sum act  EX pops
    if population_identity[0] == 'E':
        EX_counter += 1
        for i in range(n):
            EX_sum_act[i] = EX_sum_act[i] + excitPop[ i, q] +  inhibPop[ i, q]    
    # Count and sum act GC pops 
    if population_identity[0] == 'G':
        GC_counter +=1
        for i in range(n):
            GC_sum_act[i] = GC_sum_act[i] + excitPop[ i, q] +  inhibPop[ i, q]
    # Count and sum act MA pops
    if population_identity[0] == 'M':
        MA_counter +=1
        for i in range(n):
            MA_sum_act[i] = MA_sum_act[i] + excitPop[ i, q] +  inhibPop[ i, q]
    # Count and sum act SG pops 
    if population_identity[0] == 'S':
        SG_counter +=1
        for i in range(n):
            SG_sum_act[i] = SG_sum_act[i] + excitPop[ i, q] +  inhibPop[ i, q]
    # Count and sum act HD pops 
    if population_identity[0] == 'H':
        HD_counter +=1
        for i in range(n):
            HD_sum_act[i] = HD_sum_act[i] + excitPop[ i, q] +  inhibPop[ i, q]
    # Count and sum  WM pops
    if population_identity[0] == 'W':
        WM_counter +=1
        for i in range(n):
            WM_sum_act[i] = WM_sum_act[i] + excitPop[ i, q] +  inhibPop[ i, q]

# Total activity and Rest (MA + SG + HD) activity:
for i in range(n):
    Sum_act_Total[i] = (GC_sum_act[i] + MA_sum_act[i]  + WM_sum_act[i] \
                                   + SG_sum_act[i] + HD_sum_act[i] ) 
    Sum_act_Rest[i] = (MA_sum_act[i] + SG_sum_act[i] + HD_sum_act[i] )      

# All pops in SNB:
NBA_counter = GC_counter + MA_counter + WM_counter + SG_counter + HD_counter
# Total pops: SNB + external:
Pops_counter = NBA_counter + EX_counter
print('All pops in sentence neural blackboard (SNB):  ', NBA_counter)
print('External = ', EX_counter)
print('Total of all pops in simulation (SNB + external):  ', Pops_counter)

# Output files activity per category:
# Total (sum) activity
outfile = open(NBA_name+name_sim+'_Total.dat', 'w')
for j in range(n): 
    outfile.write('%12.2f' %Sum_act_Total[j])
    outfile.write('\n')
outfile.close() 

# Rest activity (aka "Other")
outfile = open(NBA_name+name_sim+'_Rest.dat', 'w')
for j in range(n):
    outfile.write('%12.2f' %Sum_act_Rest[j])
    outfile.write('\n')
outfile.close() 

# Gating circuit activity
outfile = open(NBA_name+name_sim+'_GC.dat', 'w')
for j in range(n):
    outfile.write('%12.2f' %GC_sum_act[j])
    outfile.write('\n')
outfile.close() 

# WM activity  
outfile = open(NBA_name+name_sim+'_WM.dat', 'w')
for j in range(n):
    outfile.write('%12.2f' %WM_sum_act[j])
    outfile.write('\n')
outfile.close() 

# Plots
# Plots are relative to maximum activation per ms (= 100) in category Total
max_Value = 1.0   # cannot be zero!
for i in range (n):
    if Sum_act_Total[i] > max_Value:
        max_Value = Sum_act_Total[i]
rel_Value = 100/max_Value   # used for making relative values with max = 100 

x_axis = np.linspace(0, n, n)
plt.figure(dpi=300)

plt.plot(x_axis,Sum_act_Total*rel_Value, color='orange')
plt.plot(x_axis,GC_sum_act*rel_Value, color='blue')
plt.plot(x_axis,Sum_act_Rest*rel_Value, color='green')
plt.plot(x_axis,WM_sum_act*rel_Value, color='red')

plt.ylim(0, 150)
plt.xlabel('Time (ms)')
plt.ylabel('Activity')
plt.title('Sentence activity in SNB')

plt.savefig(NBA_name+name_sim+'.png')
plt.close(NBA_name+name_sim+'.png')

# WM pops, relevant for binding information
ActivePops = np.zeros(lenlist)     #For identifying active populations
WM_CMPops = np.zeros(lenlist)     #For identifying all WM populations in connection matrix
WM_WGPops = np.zeros(lenlist)     #For identifying all WM populations in word groups
WM_SGPops = np.zeros(lenlist)     #For identifying all WM  populations in structure groups

WM_CM_active = np.zeros(lenlist)     #For identifying active WM binding populations in connection matrix
WM_WG_active = np.zeros(lenlist)     #For identifying all active WM binding populations in word groups
WM_SG_active = np.zeros(lenlist)     #For identifying all active WM  binding populations in structure groups

# Find WM pops per category: Connection matrix, word groups, structure groups
for i in range(lenlist):
    if architecture[i][2] =='WM1_Apop' and architecture[i][6] == 'Con_Matrix':   # Connection matrix
        WM_CMPops[i] =1
    if architecture[i][2] =='WM1_Apop' and architecture[i][6][0] == 'W':              # Word group
        WM_WGPops[i] = 1
    if architecture[i][2] =='WM1_Apop' and architecture[i][6] == 'S_G':              # Structure group
       WM_SGPops[i] = 1

# Find active pops: at least once more activity than 25 (= half sustained WM activity)      
for i in range(lenlist):
    for q in range(n):
        if excitPop[q,i] > 25:       
            ActivePops[i] = 1       # Count this pop as active pop
ActivePops_counter = 0
for i in range(lenlist):
    if ActivePops[i] == 1:
        ActivePops_counter += 1
        if architecture[i][2] =='WM1_Apop' and architecture[i][6] == 'Con_Matrix':
             if architecture[i][3][0] == 'B':
                 WM_CM_active[i] =1
        if architecture[i][2] =='WM1_Apop' and architecture[i][6][0] == 'W':
            if architecture[i][3][0] == 'B':
                WM_WG_active[i] = 1
        if architecture[i][2] =='WM1_Apop' and architecture[i][6] == 'S_G':
            if architecture[i][3][0] == 'B':
                WM_SG_active[i] = 1

# Testing for bindings:
print('Testing for bindings')
CM_test = []
WG_test = []
SG_test = []

for i in range(lenlist):
    if WM_CM_active[i] == 1:
        CM_test.append(i)
    if WM_WG_active[i] == 1:
        WG_test.append(i)
    if WM_SG_active[i] == 1:
        SG_test.append(i)

# Basis file for checking achieved bindings: 
file_basis_name = Binding_test+arch_size+'_Bindings_'+sentence_name

# Basis file input
CM_basis = []
WG_basis = []
SG_basis = []
file_basis = file_basis_name+'.txt'
print('Basis file = ',file_basis_name) 
# Reading file basis
with open(file_basis) as f:
    for line in f:
        str = line.split()
        if len(str) > 0:
            if len(str) > 7 and str[7] == 'Connection':
                file_type = 1
            if len(str) > 7 and str[7] == 'Word':
                file_type = 2
            if len(str) > 7 and str[7] == 'Structure':
                file_type = 3
            if str[0].isdigit():
                word_binding = str[2]
                if word_binding[0] == 'B':
                    if file_type == 1:
                        CM_basis.append(int(str[0]))
                    if file_type == 2:
                        WG_basis.append(int(str[0]))
                    if file_type == 3:
                        SG_basis.append(int(str[0]))
Total_Basis_Bindings = len(CM_basis) +  len(WG_basis) +  len(SG_basis)

# Analysis and output
outfile_basis_name = Binding_test+arch_size+'_activeBindings_'+sentence_name

Wrong = 0      # Wrong = 0: all correct bindings in CM+WG+SG
outfile = open(outfile_basis_name +'.txt', 'w')
outfile.write('Architecture:  '+NBA_arch+arch_size+ '\n')
outfile.write('Simulation:  '+sentence_name+ '\n')
outfile.write('Achieved set of bindings in simulation')  
outfile.write('\n')
outfile.write('\n')

# Testing bindings in Connection Matrix (CM)

# Sentence bindings

if len(CM_basis) != len(CM_test):
    Wrong = 1
    outfile.write('CM bindings not correct: lists are not equal' '\n')  
    outfile.write('Number of required CM bindings:')
    outfile.write(' %6d  ' %len(CM_basis))
    outfile.write('\n')
    outfile.write('Number of CM bindings in test file:')
    outfile.write(' %6d  ' %len(CM_test))
    outfile.write('\n')
    outfile.write('\n')

CMcounter = 0

if len(CM_basis) == len(CM_test):
    for q in range(len(CM_basis)):
        if CM_basis[q] == CM_test[q]:
            CMcounter +=1
    if len(CM_basis) == CMcounter:
        outfile.write('CM bindings are correct' '\n')
    if len(CM_basis) != CMcounter:
        Wrong = 1
        outfile.write('Not all CM bindings are correct' '\n')
    outfile.write('Number of equal CM bindings:')
    outfile.write(' %6d  ' % CMcounter)
    outfile.write('\n')
    outfile.write('Number of required CM bindings:')
    outfile.write(' %6d  ' %len(CM_basis))
    outfile.write('\n')
    outfile.write('Number of CM bindings in test file:')
    outfile.write(' %6d  ' %len(CM_test))
    outfile.write('\n')
    outfile.write('\n')


# Testing bindings in Word Groups (WG)
# Sentence Bindings
if len(WG_basis) != len(WG_test):
    Wrong = 1
    outfile.write('WG bindings not correct: lists are not equal' '\n')
    outfile.write('Number of required WG bindings:')
    outfile.write(' %6d  ' %len(WG_basis))
    outfile.write('\n')
    outfile.write('Number of WG bindings in test file:')
    outfile.write(' %6d  ' %len(WG_test))
    outfile.write('\n')
    outfile.write('\n')
WGcounter = 0
if len(WG_basis) == len(WG_test):
    for q in range(len(WG_basis)):
        if WG_basis[q] == WG_test[q]:
            WGcounter +=1
    if len(WG_basis) == WGcounter:
        outfile.write('WG bindings are correct' '\n')
    if len(WG_basis) != WGcounter:
        Wrong = 1
        outfile.write('Not all WG bindings are correct' '\n')
    outfile.write('Number of equal WG bindings:')
    outfile.write(' %6d  ' % WGcounter)
    outfile.write('\n')
    outfile.write('Number of required WG bindings:')
    outfile.write(' %6d  ' %len(WG_basis))
    outfile.write('\n')
    outfile.write('Number of WG bindings in test file:')
    outfile.write(' %6d  ' %len(WG_test))
    outfile.write('\n')
    outfile.write('\n')

# Testing bindings in Structure Groups (SG)
# Sentence Bindings
if len(SG_basis) != len(SG_test):
    Wrong = 1
    outfile.write('SG bindings not correct: lists are not equal' '\n')
    outfile.write('Number of required SG bindings:')
    outfile.write(' %6d  ' %len(SG_basis))
    outfile.write('\n')
    outfile.write('Number of SG bindings in test file:')
    outfile.write(' %6d  ' %len(SG_test))
    outfile.write('\n')
    outfile.write('\n')
SGcounter = 0
if len(SG_basis) == len(SG_test):
    for q in range(len(SG_basis)):
        if SG_basis[q] == SG_test[q]:
            SGcounter +=1
    if len(SG_basis) == SGcounter:
        outfile.write('SG bindings are correct' '\n')
    if len(SG_basis) != SGcounter:
        Wrong = 1
        outfile.write('Not all SG bindings are correct' '\n')
    outfile.write('Number of equal SG bindings:')
    outfile.write(' %6d  ' % SGcounter)
    outfile.write('\n')
    outfile.write('Number of required SG bindings:')
    outfile.write(' %6d  ' %len(SG_basis))
    outfile.write('\n')
    outfile.write('Number of SG bindings in test file:')
    outfile.write(' %6d  ' %len(SG_test))
    outfile.write('\n')
    outfile.write('\n')

# Overall binding results
outfile.write('Overall binding results:')
outfile.write('\n')
if Wrong == 0:
    outfile.write('ALL SENTENCE BINDINGS ARE CORRECT'  '\n')
if Wrong == 1:
    outfile.write('NOT all sentence bindings are CORRECT'  '\n')
outfile.write('Number of required sentence bindings:  ')
outfile.write(' %6d  ' % Total_Basis_Bindings)
outfile.write('\n')
outfile.write('Number of found sentence bindings (= 0 with unequal lists):  ')
outfile.write(' %6d  ' % (CMcounter + WGcounter + SGcounter))
outfile.write('\n')    
outfile.write('\n')

# Active bindings
outfile.write('Active bindings:')
outfile.write('\n')
outfile.write('\n')
outfile.write('Active WM populations in Binding circuits in Connection Matrix '  '\n')
outfile.write('p_index     pop          circuit           H-row     D-row       group    ' '\n')
for k in range(len(CM_test)):
    i = CM_test[k]  
    outfile.write(' %6d  ' % i)         # i = population index number 
    outfile.write(' {0:10s}'.format(architecture[i][2]))
    outfile.write(' {0:20s}'.format(architecture[i][3]))
    outfile.write(' {0:10s}'.format(architecture[i][4]))
    outfile.write(' {0:10s}'.format(architecture[i][5]))
    outfile.write(' {0:15s}'.format(architecture[i][6]))
    outfile.write('\n')

outfile.write('\n')
outfile.write('Active WM populations in Binding circuits in Word Groups '  '\n')
outfile.write('p_index     pop            circuit               group    ' '\n') 
for k in range(len(WG_test)):
    i = WG_test[k]
    outfile.write(' %6d  ' % i)         # i = population index number 
    outfile.write(' {0:15s}'.format(architecture[i][2]))
    outfile.write(' {0:23s}'.format(architecture[i][3]))
    outfile.write(' {0:15s}'.format(architecture[i][6]))
    outfile.write('\n')

outfile.write('\n')
outfile.write('Active WM populations in Binding circuits in Structure Groups '  '\n')
outfile.write('p_index     pop          circuit               H-row      D-row     group    ' '\n') 
for k in range(len(SG_test)):
    i = SG_test[k]
    outfile.write(' %6d  ' % i)         # i = population index number 
    outfile.write(' {0:10s}'.format(architecture[i][2]))
    outfile.write(' {0:25s}'.format(architecture[i][3]))
    outfile.write(' {0:10s}'.format(architecture[i][4]))
    outfile.write(' {0:10s}'.format(architecture[i][5]))
    outfile.write(' {0:15s}'.format(architecture[i][6]))
    outfile.write('\n')   

outfile.write('\n')
outfile.close()








